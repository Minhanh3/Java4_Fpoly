package com.example.kthu_nang_cao.lab8.P2;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Sach {
    private String id ;
    private String ten ;
    private int sotrang ;
    private String tenTacgia ;
    private int lanTaiBan ;

}
