package com.example.kthu_nang_cao.lab7;

public class bai1 {
    public int chia(int a, int b) {
        return a / b;
    }
}
